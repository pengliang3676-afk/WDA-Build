#import "XLAppDelegate.h"
#import "XLViewController.h"

@implementation XLAppDelegate

- (BOOL)application:(UIApplication *)application
    didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    (void)application;
    (void)launchOptions;

    NSString *documents = NSSearchPathForDirectoriesInDomains(
        NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    [NSFileManager.defaultManager createDirectoryAtPath:documents
                            withIntermediateDirectories:YES
                                             attributes:nil
                                                  error:nil];

    self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    self.window.rootViewController = [XLViewController new];
    [self.window makeKeyAndVisible];
    return YES;
}

@end
