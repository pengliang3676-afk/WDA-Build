#import <UIKit/UIKit.h>
#import "XLAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass(XLAppDelegate.class));
    }
}
