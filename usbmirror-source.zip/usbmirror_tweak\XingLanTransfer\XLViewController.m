#import "XLViewController.h"

@implementation XLViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:0.04 green:0.08 blue:0.14 alpha:1.0];

    UILabel *title = [UILabel new];
    title.translatesAutoresizingMaskIntoConstraints = NO;
    title.text = @"星澜传输";
    title.textColor = UIColor.whiteColor;
    title.font = [UIFont boldSystemFontOfSize:30.0];
    title.textAlignment = NSTextAlignmentCenter;

    UILabel *message = [UILabel new];
    message.translatesAutoresizingMaskIntoConstraints = NO;
    message.text = @"USB传输的文件会自动保存在这里\n\n请在系统“文件”App中打开\n我的 iPhone → 星澜传输";
    message.textColor = [UIColor colorWithWhite:0.82 alpha:1.0];
    message.font = [UIFont systemFontOfSize:17.0];
    message.numberOfLines = 0;
    message.textAlignment = NSTextAlignmentCenter;

    [self.view addSubview:title];
    [self.view addSubview:message];
    [NSLayoutConstraint activateConstraints:@[
        [title.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
        [title.centerYAnchor constraintEqualToAnchor:self.view.centerYAnchor constant:-75.0],
        [message.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:30.0],
        [message.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-30.0],
        [message.topAnchor constraintEqualToAnchor:title.bottomAnchor constant:35.0]
    ]];
}

@end
