#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>

static const int XLFileTransferPort = 6003;
static const uint64_t XLMaximumFileSize = 8ULL * 1024ULL * 1024ULL * 1024ULL;
static NSString * const XLTransferAppBundleIdentifier = @"com.jibeib.xinglantransfer";
static NSString * const XLLocalFileProviderGroupIdentifier =
    @"group.com.apple.FileProvider.LocalStorage";

static BOOL XLReadAll(int socketHandle, void *buffer, size_t length)
{
    uint8_t *bytes = (uint8_t *)buffer;
    size_t offset = 0;
    while (offset < length) {
        ssize_t received = recv(socketHandle, bytes + offset, length - offset, 0);
        if (received <= 0) return NO;
        offset += (size_t)received;
    }
    return YES;
}

static BOOL XLWriteAll(int socketHandle, const void *buffer, size_t length)
{
    const uint8_t *bytes = (const uint8_t *)buffer;
    size_t offset = 0;
    while (offset < length) {
        ssize_t written = send(socketHandle, bytes + offset, length - offset, 0);
        if (written <= 0) return NO;
        offset += (size_t)written;
    }
    return YES;
}

static void XLSendResult(int client, BOOL success, NSString *message, NSString *path)
{
    NSDictionary *result = @{
        @"success": @(success),
        @"message": message ?: @"",
        @"path": path ?: @""
    };
    NSData *json = [NSJSONSerialization dataWithJSONObject:result options:0 error:nil];
    if (!json.length) return;
    NSMutableData *line = [json mutableCopy];
    [line appendBytes:"\n" length:1];
    XLWriteAll(client, line.bytes, line.length);
}

static NSString *XLSafeFileName(NSString *rawName)
{
    NSString *name = rawName.lastPathComponent;
    if (!name.length || [name isEqualToString:@"."] || [name isEqualToString:@".."]) {
        name = [NSString stringWithFormat:@"file-%@.bin", NSUUID.UUID.UUIDString];
    }
    NSCharacterSet *forbidden = [NSCharacterSet characterSetWithCharactersInString:@"/\\:"];
    name = [[name componentsSeparatedByCharactersInSet:forbidden] componentsJoinedByString:@"_"];
    return name.length ? name : @"received-file.bin";
}

static NSString *XLUniqueDestination(NSString *directory, NSString *fileName)
{
    NSFileManager *manager = NSFileManager.defaultManager;
    NSString *destination = [directory stringByAppendingPathComponent:fileName];
    if (![manager fileExistsAtPath:destination]) return destination;

    NSString *base = fileName.stringByDeletingPathExtension;
    NSString *extension = fileName.pathExtension;
    for (NSUInteger index = 1; index < 10000; index++) {
        NSString *candidateName = extension.length
            ? [NSString stringWithFormat:@"%@-%lu.%@", base, (unsigned long)index, extension]
            : [NSString stringWithFormat:@"%@-%lu", base, (unsigned long)index];
        NSString *candidate = [directory stringByAppendingPathComponent:candidateName];
        if (![manager fileExistsAtPath:candidate]) return candidate;
    }
    return [directory stringByAppendingPathComponent:
            [NSString stringWithFormat:@"%@-%@", NSUUID.UUID.UUIDString, fileName]];
}

static NSString *XLTransferDocumentsDirectory(void)
{
    NSFileManager *manager = NSFileManager.defaultManager;

    // Prefer the system local file-provider storage. Files saved here appear
    // directly under Files -> On My iPhone, even though this package's helper
    // app is installed as a jailbreak system app and has no normal app sandbox.
    NSArray<NSString *> *sharedContainerRoots = @[
        @"/var/mobile/Containers/Shared/AppGroup",
        @"/private/var/mobile/Containers/Shared/AppGroup"
    ];
    for (NSString *root in sharedContainerRoots) {
        NSArray<NSString *> *entries = [manager contentsOfDirectoryAtPath:root error:nil];
        for (NSString *entry in entries) {
            NSString *container = [root stringByAppendingPathComponent:entry];
            NSString *metadataPath =
                [container stringByAppendingPathComponent:
                 @".com.apple.mobile_container_manager.metadata.plist"];
            NSDictionary *metadata = [NSDictionary dictionaryWithContentsOfFile:metadataPath];
            NSString *identifier = metadata[@"MCMMetadataIdentifier"];
            if ([identifier isEqualToString:XLLocalFileProviderGroupIdentifier]) {
                NSString *providerStorage =
                    [container stringByAppendingPathComponent:@"File Provider Storage"];
                return [providerStorage stringByAppendingPathComponent:@"星澜传输"];
            }
        }
    }

    // Fallback for systems where the companion app receives a regular data
    // container (for example when it is installed by a sandbox-aware installer).
    NSArray<NSString *> *containerRoots = @[
        @"/var/mobile/Containers/Data/Application",
        @"/private/var/mobile/Containers/Data/Application"
    ];

    for (NSString *root in containerRoots) {
        NSArray<NSString *> *entries = [manager contentsOfDirectoryAtPath:root error:nil];
        for (NSString *entry in entries) {
            NSString *container = [root stringByAppendingPathComponent:entry];
            NSString *metadataPath =
                [container stringByAppendingPathComponent:
                 @".com.apple.mobile_container_manager.metadata.plist"];
            NSDictionary *metadata = [NSDictionary dictionaryWithContentsOfFile:metadataPath];
            NSString *identifier = metadata[@"MCMMetadataIdentifier"];
            if ([identifier isEqualToString:XLTransferAppBundleIdentifier]) {
                return [container stringByAppendingPathComponent:@"Documents"];
            }
        }
    }
    return nil;
}

static void XLImportImageAtPath(NSString *path)
{
    NSData *data = [NSData dataWithContentsOfFile:path options:NSDataReadingMappedIfSafe error:nil];
    UIImage *image = data ? [UIImage imageWithData:data] : nil;
    if (!image) return;
    dispatch_async(dispatch_get_main_queue(), ^{
        UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil);
    });
}

static void XLHandleFileClient(int client)
{
    @autoreleasepool {
        int noSignal = 1;
        setsockopt(client, SOL_SOCKET, SO_NOSIGPIPE, &noSignal, sizeof(noSignal));

        do {
        uint8_t header[16] = {0};
        if (!XLReadAll(client, header, sizeof(header)) || memcmp(header, "XLFT", 4) != 0) {
            XLSendResult(client, NO, @"文件协议错误", nil);
            break;
        }

        uint32_t metadataLengthBE = 0;
        uint64_t fileLengthBE = 0;
        memcpy(&metadataLengthBE, header + 4, sizeof(metadataLengthBE));
        memcpy(&fileLengthBE, header + 8, sizeof(fileLengthBE));
        uint32_t metadataLength = ntohl(metadataLengthBE);
        uint64_t fileLength = CFSwapInt64BigToHost(fileLengthBE);
        if (metadataLength == 0 || metadataLength > 64 * 1024 ||
            fileLength == 0 || fileLength > XLMaximumFileSize) {
            XLSendResult(client, NO, @"文件大小或信息无效", nil);
            break;
        }

        NSMutableData *metadataData = [NSMutableData dataWithLength:metadataLength];
        if (!XLReadAll(client, metadataData.mutableBytes, metadataLength)) {
            XLSendResult(client, NO, @"文件信息接收失败", nil);
            break;
        }
        NSDictionary *metadata = [NSJSONSerialization JSONObjectWithData:metadataData options:0 error:nil];
        if (![metadata isKindOfClass:NSDictionary.class]) {
            XLSendResult(client, NO, @"文件信息无法识别", nil);
            break;
        }

        NSString *fileName = XLSafeFileName([metadata[@"name"] description]);
        BOOL importPhoto = [metadata[@"importPhoto"] boolValue];
        NSString *directory = XLTransferDocumentsDirectory();
        if (!directory.length) {
            XLSendResult(client, NO, @"请先在手机上打开一次“星澜传输”App", nil);
            break;
        }
        NSError *directoryError = nil;
        if (![NSFileManager.defaultManager createDirectoryAtPath:directory
                                      withIntermediateDirectories:YES
                                                       attributes:nil
                                                            error:&directoryError]) {
            XLSendResult(client, NO, directoryError.localizedDescription ?: @"无法创建保存目录", nil);
            break;
        }

        NSString *destination = XLUniqueDestination(directory, fileName);
        if (![NSFileManager.defaultManager createFileAtPath:destination contents:nil attributes:nil]) {
            XLSendResult(client, NO, @"无法创建手机端文件", nil);
            break;
        }

        NSFileHandle *output = [NSFileHandle fileHandleForWritingAtPath:destination];
        if (!output) {
            [NSFileManager.defaultManager removeItemAtPath:destination error:nil];
            XLSendResult(client, NO, @"无法打开手机端文件", nil);
            break;
        }

        BOOL receivedSuccessfully = YES;
        uint64_t remaining = fileLength;
        uint8_t buffer[256 * 1024];
        @try {
            while (remaining > 0) {
                size_t wanted = (size_t)MIN((uint64_t)sizeof(buffer), remaining);
                ssize_t received = recv(client, buffer, wanted, 0);
                if (received <= 0) {
                    receivedSuccessfully = NO;
                    break;
                }
                [output writeData:[NSData dataWithBytesNoCopy:buffer
                                                       length:(NSUInteger)received
                                                 freeWhenDone:NO]];
                remaining -= (uint64_t)received;
            }
            [output synchronizeFile];
            [output closeFile];
        } @catch (__unused NSException *exception) {
            receivedSuccessfully = NO;
            @try { [output closeFile]; } @catch (__unused NSException *ignored) {}
        }

        if (!receivedSuccessfully || remaining != 0) {
            [NSFileManager.defaultManager removeItemAtPath:destination error:nil];
            XLSendResult(client, NO, @"USB传输中断，未保留残缺文件", nil);
            break;
        }

        if (importPhoto) XLImportImageAtPath(destination);
        NSString *message = importPhoto ? @"文件已保存，并已提交到系统相册" : @"文件已保存";
        XLSendResult(client, YES, message, destination);
        } while (false);
        shutdown(client, SHUT_RDWR);
        close(client);
    }
}

static void XLRunFileTransferServer(void)
{
    int server = socket(AF_INET, SOCK_STREAM, 0);
    if (server < 0) return;
    int enabled = 1;
    setsockopt(server, SOL_SOCKET, SO_REUSEADDR, &enabled, sizeof(enabled));
    struct sockaddr_in address = {0};
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(INADDR_ANY);
    address.sin_port = htons(XLFileTransferPort);
    if (bind(server, (struct sockaddr *)&address, sizeof(address)) != 0 ||
        listen(server, 8) != 0) {
        close(server);
        return;
    }

    while (true) {
        int client = accept(server, NULL, NULL);
        if (client < 0) continue;
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
            XLHandleFileClient(client);
        });
    }
}

__attribute__((constructor))
static void XLStartFileTransferServer(void)
{
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        XLRunFileTransferServer();
    });
}
